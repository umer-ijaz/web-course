const express = require("express")
const router = express.Router()
const { products } = require("../data/products")

// Products page
router.get("/", (req, res) => {
  const { category, search } = req.query
  let filteredProducts = products

  if (category) {
    filteredProducts = products.filter((p) => p.category === category)
  }

  if (search) {
    filteredProducts = filteredProducts.filter((p) => p.name.toLowerCase().includes(search.toLowerCase()))
  }

  res.render("products/index", {
    title: "Products - Jack Wills",
    products: filteredProducts,
    currentCategory: category,
    searchQuery: search,
  })
})

// Single product page
router.get("/:id", (req, res) => {
  const product = products.find((p) => p.id === Number.parseInt(req.params.id))

  if (!product) {
    return res.status(404).render("404", { title: "Product Not Found" })
  }

  res.render("products/single", {
    title: `${product.name} - Jack Wills`,
    product: product,
  })
})

module.exports = router
