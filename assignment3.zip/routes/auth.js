const express = require("express")
const bcrypt = require("bcryptjs")
const { body, validationResult } = require("express-validator")
const router = express.Router()
const { findUserByEmail, createUser } = require("../data/users")
const { redirectIfAuth } = require("../middleware/auth")

// Login page
router.get("/login", redirectIfAuth, (req, res) => {
  res.render("auth/login", {
    title: "Login - Jack Wills",
    layout: "layouts/auth",
  })
})

// Register page
router.get("/register", redirectIfAuth, (req, res) => {
  res.render("auth/register", {
    title: "Register - Jack Wills",
    layout: "layouts/auth",
  })
})

// Login POST
router.post("/login", [body("email").isEmail().normalizeEmail(), body("password").notEmpty()], async (req, res) => {
  const errors = validationResult(req)

  if (!errors.isEmpty()) {
    return res.render("auth/login", {
      title: "Login - Jack Wills",
      layout: "layouts/auth",
      errors: errors.array(),
      email: req.body.email,
    })
  }

  const { email, password } = req.body
  const user = findUserByEmail(email)

  if (!user) {
    req.flash("error_msg", "Invalid email or password")
    return res.redirect("/auth/login")
  }

  const isMatch = await bcrypt.compare(password, user.password)

  if (!isMatch) {
    req.flash("error_msg", "Invalid email or password")
    return res.redirect("/auth/login")
  }

  // Create session
  req.session.user = {
    id: user.id,
    name: user.name,
    email: user.email,
  }

  req.flash("success_msg", "Welcome back!")
  res.redirect("/")
})

// Register POST
router.post(
  "/register",
  [
    body("name").trim().isLength({ min: 2 }),
    body("email").isEmail().normalizeEmail(),
    body("password").isLength({ min: 6 }),
    body("confirmPassword").custom((value, { req }) => {
      if (value !== req.body.password) {
        throw new Error("Passwords do not match")
      }
      return true
    }),
  ],
  async (req, res) => {
    const errors = validationResult(req)

    if (!errors.isEmpty()) {
      return res.render("auth/register", {
        title: "Register - Jack Wills",
        layout: "layouts/auth",
        errors: errors.array(),
        name: req.body.name,
        email: req.body.email,
      })
    }

    const { name, email, password } = req.body

    // Check if user already exists
    if (findUserByEmail(email)) {
      req.flash("error_msg", "User with this email already exists")
      return res.redirect("/auth/register")
    }

    // Hash password
    const hashedPassword = await bcrypt.hash(password, 10)

    // Create user
    const newUser = createUser({
      name,
      email,
      password: hashedPassword,
    })

    req.flash("success_msg", "Registration successful! Please log in.")
    res.redirect("/auth/login")
  },
)

// Logout
router.post("/logout", (req, res) => {
  req.session.destroy((err) => {
    if (err) {
      console.error("Session destruction error:", err)
    }
    res.redirect("/")
  })
})

module.exports = router
