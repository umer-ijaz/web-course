const express = require("express")
const router = express.Router()
const { products } = require("../data/products")

// Initialize cart in session if it doesn't exist
const initCart = (req) => {
  if (!req.session.cart) {
    req.session.cart = []
  }
}

// Get cart page
router.get("/", (req, res) => {
  initCart(req)

  // Calculate cart totals
  let subtotal = 0
  const cartItems = req.session.cart
    .map((item) => {
      const product = products.find((p) => p.id === item.productId)
      if (product) {
        const price = product.salePrice || product.price
        const itemTotal = price * item.quantity
        subtotal += itemTotal
        return {
          ...item,
          product: product,
          price: price,
          total: itemTotal,
        }
      }
      return null
    })
    .filter((item) => item !== null)

  const tax = subtotal * 0.1 // 10% tax
  const total = subtotal + tax

  res.render("cart/index", {
    title: "Shopping Cart - Jack Wills",
    cartItems: cartItems,
    subtotal: subtotal,
    tax: tax,
    total: total,
  })
})

// Add to cart
router.post("/add", (req, res) => {
  initCart(req)

  const { productId, quantity = 1, size = "M" } = req.body
  const product = products.find((p) => p.id === Number.parseInt(productId))

  if (!product) {
    req.flash("error_msg", "Product not found")
    return res.redirect("/products")
  }

  // Check if item already exists in cart
  const existingItemIndex = req.session.cart.findIndex(
    (item) => item.productId === Number.parseInt(productId) && item.size === size,
  )

  if (existingItemIndex > -1) {
    // Update quantity if item exists
    req.session.cart[existingItemIndex].quantity += Number.parseInt(quantity)
  } else {
    // Add new item to cart
    req.session.cart.push({
      productId: Number.parseInt(productId),
      quantity: Number.parseInt(quantity),
      size: size,
      addedAt: new Date(),
    })
  }

  req.flash("success_msg", `${product.name} added to cart!`)
  res.redirect(`/products/${productId}`)
})

// Update cart item quantity
router.post("/update", (req, res) => {
  initCart(req)

  const { productId, size, quantity } = req.body
  const itemIndex = req.session.cart.findIndex(
    (item) => item.productId === Number.parseInt(productId) && item.size === size,
  )

  if (itemIndex > -1) {
    if (Number.parseInt(quantity) <= 0) {
      // Remove item if quantity is 0 or less
      req.session.cart.splice(itemIndex, 1)
      req.flash("success_msg", "Item removed from cart")
    } else {
      // Update quantity
      req.session.cart[itemIndex].quantity = Number.parseInt(quantity)
      req.flash("success_msg", "Cart updated")
    }
  }

  res.redirect("/cart")
})

// Remove item from cart
router.post("/remove", (req, res) => {
  initCart(req)

  const { productId, size } = req.body
  const itemIndex = req.session.cart.findIndex(
    (item) => item.productId === Number.parseInt(productId) && item.size === size,
  )

  if (itemIndex > -1) {
    const product = products.find((p) => p.id === Number.parseInt(productId))
    req.session.cart.splice(itemIndex, 1)
    req.flash("success_msg", `${product ? product.name : "Item"} removed from cart`)
  }

  res.redirect("/cart")
})

// Clear cart
router.post("/clear", (req, res) => {
  req.session.cart = []
  req.flash("success_msg", "Cart cleared")
  res.redirect("/cart")
})

module.exports = router
