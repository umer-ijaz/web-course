const express = require("express")
const router = express.Router()
const { products, categories } = require("../data/products")

// Home page
router.get("/", (req, res) => {
  res.render("index", {
    title: "Jack Wills - Home",
    products: products,
    categories: categories,
  })
})

// About page
router.get("/about", (req, res) => {
  res.render("about", {
    title: "About Us - Jack Wills",
  })
})

module.exports = router
