// In-memory user storage (use a database in production)
const users = []

const findUserByEmail = (email) => {
  return users.find((user) => user.email === email)
}

const findUserById = (id) => {
  return users.find((user) => user.id === id)
}

const createUser = (userData) => {
  const newUser = {
    id: users.length + 1,
    ...userData,
    createdAt: new Date(),
  }
  users.push(newUser)
  return newUser
}

module.exports = {
  users,
  findUserByEmail,
  findUserById,
  createUser,
}
