const products = [
  {
    id: 1,
    name: "Sandleford T-Shirt",
    price: 24.99,
    salePrice: null,
    image: "/images/white_tee.avif",
    category: "clothing",
  },
  {
    id: 2,
    name: "Sandleford T-Shirt",
    price: 24.99,
    salePrice: 9.0,
    image: "/images/brown_tee.avif",
    category: "clothing",
  },
  {
    id: 3,
    name: "Sandleford T-Shirt",
    price: 24.99,
    salePrice: 9.0,
    image: "/images/greentee.avif",
    category: "clothing",
  },
  {
    id: 4,
    name: "Mule Sandals",
    price: 69.99,
    salePrice: 35.0,
    image: "/images/sandals.avif",
    category: "footwear",
  },
  {
    id: 5,
    name: "Ayleford T-Shirt",
    price: 24.99,
    salePrice: 8.0,
    image: "/images/ayelford.avif",
    category: "clothing",
  },
]

const categories = [
  { name: "Women", slug: "women" },
  { name: "Men", slug: "men" },
  { name: "Kids", slug: "kids" },
  { name: "Outlets", slug: "outlets" },
]

module.exports = {
  products,
  categories,
}
