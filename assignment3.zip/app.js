const express = require("express")
const session = require("express-session")
const flash = require("connect-flash")
const expressLayouts = require("express-ejs-layouts")
const path = require("path")

const app = express()
const PORT = process.env.PORT || 3000

// Import routes
const indexRoutes = require("./routes/index")
const authRoutes = require("./routes/auth")
const productRoutes = require("./routes/products")
const cartRoutes = require("./routes/cart")

// Middleware
app.use(express.urlencoded({ extended: true }))
app.use(express.json())
app.use(express.static(path.join(__dirname, "public")))

// Session configuration
app.use(
  session({
    secret: "your-secret-key-here",
    resave: false,
    saveUninitialized: false,
    cookie: {
      secure: false, // Set to true in production with HTTPS
      maxAge: 24 * 60 * 60 * 1000, // 24 hours
    },
  }),
)

// Flash messages
app.use(flash())

// EJS setup
app.set("view engine", "ejs")
app.set("views", path.join(__dirname, "views"))
app.use(expressLayouts)
app.set("layout", "layouts/main")

// Global variables for templates
app.use((req, res, next) => {
  res.locals.user = req.session.user || null
  res.locals.isAuthenticated = !!req.session.user
  res.locals.success_msg = req.flash("success_msg")
  res.locals.error_msg = req.flash("error_msg")
  res.locals.error = req.flash("error")
  res.locals.cart = req.session.cart || []
  res.locals.cartCount = req.session.cart ? req.session.cart.reduce((total, item) => total + item.quantity, 0) : 0
  next()
})

// Routes
app.use("/", indexRoutes)
app.use("/auth", authRoutes)
app.use("/products", productRoutes)
app.use("/cart", cartRoutes)

// 404 handler
app.use((req, res) => {
  res.status(404).render("404", { title: "Page Not Found" })
})

// Error handler
app.use((err, req, res, next) => {
  console.error(err.stack)
  res.status(500).render("error", {
    title: "Server Error",
    error: err.message,
  })
})

app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`)
})
