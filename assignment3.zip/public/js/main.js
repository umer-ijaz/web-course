// Carousel functionality
document.addEventListener("DOMContentLoaded", () => {
  const track = document.getElementById("carouselTrack")
  const prevBtn = document.getElementById("prevBtn")
  const nextBtn = document.getElementById("nextBtn")

  if (track && prevBtn && nextBtn) {
    const cardWidth = 287 // 267px width + 20px gap

    prevBtn.addEventListener("click", () => {
      track.scrollBy({
        left: -cardWidth,
        behavior: "smooth",
      })
    })

    nextBtn.addEventListener("click", () => {
      track.scrollBy({
        left: cardWidth,
        behavior: "smooth",
      })
    })
  }

  // Auto-hide alerts after 5 seconds
  const alerts = document.querySelectorAll(".alert")
  alerts.forEach((alert) => {
    setTimeout(() => {
      alert.style.opacity = "0"
      setTimeout(() => {
        alert.remove()
      }, 300)
    }, 5000)
  })
})

// Add to wishlist function
function addToWishlist(productId) {
  // For now, just show an alert. In a real app, this would make an API call
  alert("Added to wishlist! (This feature will be implemented in a future update)")
}

// Checkout function
function checkout() {
  alert("Checkout functionality will be implemented soon!")
}

// Update cart quantity on change
function updateQuantity(productId, size, quantity) {
  if (quantity < 1) {
    if (confirm("Remove this item from cart?")) {
      // Submit remove form
      const form = document.createElement("form")
      form.method = "POST"
      form.action = "/cart/remove"

      const productInput = document.createElement("input")
      productInput.type = "hidden"
      productInput.name = "productId"
      productInput.value = productId

      const sizeInput = document.createElement("input")
      sizeInput.type = "hidden"
      sizeInput.name = "size"
      sizeInput.value = size

      form.appendChild(productInput)
      form.appendChild(sizeInput)
      document.body.appendChild(form)
      form.submit()
    }
  }
}
