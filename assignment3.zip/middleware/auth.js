// Authentication middleware
const requireAuth = (req, res, next) => {
  if (req.session.user) {
    next()
  } else {
    req.flash("error_msg", "Please log in to access this page")
    res.redirect("/auth/login")
  }
}

// Redirect if already authenticated
const redirectIfAuth = (req, res, next) => {
  if (req.session.user) {
    res.redirect("/")
  } else {
    next()
  }
}

module.exports = {
  requireAuth,
  redirectIfAuth,
}
